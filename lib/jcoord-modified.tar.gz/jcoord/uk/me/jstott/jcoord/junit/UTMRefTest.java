package uk.me.jstott.jcoord.junit;

import junit.framework.TestCase;


/**
 * <p>
 * UTMRef unit tests.
 * </p>
 * 
 * <p>
 * (c) 2006 Jonathan Stott
 * </p>
 *
 * <p>
 * Created on 12-Mar-2006
 * </p>
 *
 * @author Jonathan Stott
 * @version 1.1
 * @since 1.1
 */
public class UTMRefTest extends TestCase {

  /*
   * Test method for 'uk.me.jstott.jcoord.UTMRef.UTMRef(int, char, double, double)'
   */
  public void testUTMRefIntCharDoubleDouble() {

  }


  /*
   * Test method for 'uk.me.jstott.jcoord.UTMRef.toLatLng()'
   */
  public void testToLatLng() {

  }


  /*
   * Test method for 'uk.me.jstott.jcoord.UTMRef.toString()'
   */
  public void testToString() {

  }

}
