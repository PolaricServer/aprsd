package uk.me.jstott.jcoord.datum;

import uk.me.jstott.jcoord.RefEll;

/**
 * <p>
 * This class is part of the Jcoord package. Visit the <a
 * href="http://www.jstott.me.uk/jcoord/">Jcoord</a> website for more
 * information.
 * </p>
 * 
 * <p>
 * </p>
 * 
 * <p>
 * (c) 2006 Jonathan Stott
 * </p>
 * 
 * <p>
 * Created on 05-Mar-2006
 * </p>
 * 
 * @author Jonathan Stott
 * @version 1.2
 * @since 1.2
 */
public class OSGB36 extends Datum {

  /**
   * 
   * 
   * @since 1.2
   */
  public OSGB36() {
    name = "Ordnance Survey of Great Britain 1936";
    ellipsoid = RefEll.AIRY_1830;
    dx = 446.448;
    dy = -125.157;
    dz = 542.06;
    ds = -20.49;
    rx = 0.150;
    ry = 0.2470;
    rz = 0.8421;
  }
}
