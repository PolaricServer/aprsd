package uk.me.jstott.jcoord.datum;

import uk.me.jstott.jcoord.RefEll;

/**
 * <p>
 * This class is part of the Jcoord package. Visit the <a
 * href="http://www.jstott.me.uk/jcoord/">Jcoord</a> website for more
 * information.
 * </p>
 * 
 * <p>
 * </p>
 * 
 * <p>
 * (c) 2006 Jonathan Stott
 * </p>
 * 
 * <p>
 * Created on 05-Mar-2006
 * </p>
 * 
 * @author Jonathan Stott
 * @version 1.2
 * @since 1.2
 */
public abstract class Datum {

  protected String name;

  protected RefEll ellipsoid;

  protected double dx;

  protected double dy;

  protected double dz;

  protected double ds;

  protected double rx;

  protected double ry;

  protected double rz;


  /**
   * 
   * 
   * @return
   * @since 1.2
   */
  public String getName() {
    return name;
  }


  /**
   * 
   * 
   * @return
   * @since 1.2
   */
  public RefEll getReferenceEllipsoid() {
    return ellipsoid;
  }


  /**
   * 
   * 
   * @return the ds
   * @since 1.2
   */
  public double getDs() {
    return ds;
  }


  /**
   * 
   * 
   * @return the dx
   * @since 1.2
   */
  public double getDx() {
    return dx;
  }


  /**
   * 
   * 
   * @return the dy
   * @since 1.2
   */
  public double getDy() {
    return dy;
  }


  /**
   * 
   * 
   * @return the dz
   * @since 1.2
   */
  public double getDz() {
    return dz;
  }


  /**
   * 
   * 
   * @return the rx
   * @since 1.2
   */
  public double getRx() {
    return rx;
  }


  /**
   * 
   * 
   * @return the ry
   * @since 1.2
   */
  public double getRy() {
    return ry;
  }


  /**
   * 
   * 
   * @return the rz
   * @since 1.2
   */
  public double getRz() {
    return rz;
  }


  /**
   * 
   * 
   * @since 1.2
   */
  public String toString() {
    return getName() + " " + ellipsoid.toString() + " dx=" + dx + " dy=" + dy
        + " dz=" + dz + " ds=" + ds + " rx=" + rx + " ry=" + ry + " rz=" + rz;
  }

}
