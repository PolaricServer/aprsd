package uk.me.jstott.jcoord;
 
public interface Reference
{
  public LatLng toLatLng();
  
}
