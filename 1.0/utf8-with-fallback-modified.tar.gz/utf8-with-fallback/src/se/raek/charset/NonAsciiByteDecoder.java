package se.raek.charset;

public interface NonAsciiByteDecoder {
	
	char decodeByte(byte b);

}
